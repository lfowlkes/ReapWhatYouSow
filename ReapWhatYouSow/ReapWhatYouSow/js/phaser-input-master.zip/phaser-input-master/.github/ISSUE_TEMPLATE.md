Before opening this issue _please_ check we haven't already fixed it! Check the [Closed issues](https://github.com/azerion/phaser-input/issues?q=is%3Aissue+is%3Aclosed)
This Issue is about (delete as applicable)

* A bug in the API (always say which version you're using!)
* An error in the documentation
* An error in the example
* A problem with my own code

API errors must include example code showing what happens, and why you don't believe this is the expected behavior. Issues posted without code take _far_ longer to get resolved, _if ever_.
